

cc.Class({
    extends: cc.Component,

    properties: {
        Regis_Event_Handler:{
            default : null,
            type: cc.Component.EventHandler,
        },
        
        
        demo: require("sroll_windown")
        

    },
    Show_Window(){
        this.node.active = true;
        this.node.opacity = 0;
        this.node.scale = 0.2;
        cc.tween(this.node)
        .to(0.5,{scale:1,opacity: 255 },{easing: "quartInOut"})
        .start();

    },
    Hide_Window(){
        cc.tween(this.node)
        .to(0.5,{scale: 0.2, opacity: 0 },{easing: "quartInOut"})
        .call(()=> {this.node.active = false; })
        .start();

    },
    RegisClick(){
        if(this.Regis_Event_Handler){
        this.Regis_Event_Handler.emit();
    }
        this.Hide_Window();
    },

    start () {

    },

    
});
